<?php

    function dibuja($oportunidad){

        return "<img src='./img/ahorcado$oportunidad.jpg'>";

    }

?>